create function tri_dforms() returns trigger
    language plpgsql
as
$$
DECLARE

v_dt timestamp;

begin
  -- Insere automaticamente todo form no perfil ADM
  v_dt := timeofday();
  insert into fperfor (per_id, for_id, pfo_dtsis) values (4, new.for_id, v_dt);
  Return New;
end;
$$;

alter function tri_dforms() owner to "SafeGold";

