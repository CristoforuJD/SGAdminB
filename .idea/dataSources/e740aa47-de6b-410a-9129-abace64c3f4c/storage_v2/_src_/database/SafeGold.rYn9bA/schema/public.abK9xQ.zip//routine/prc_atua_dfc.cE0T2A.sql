create function prc_atua_dfc(p_sub integer, p_ano integer, p_mes integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 10/2018
-- Atualiza DFC Mes
--

pla        record;
reg        record;
vet        record;
v_count    integer;
v_dfmid    integer[];
v_vlrr     numeric[];

begin
  for pla in (select a.pla_id, a.pla_ordem, a.pla_totsn, a.pro_id
                from dplanoconta a, 	dsubprojeto b
               where b.sub_id = p_sub
                 and a.pro_id = b.pro_id)
  loop
    v_count := 0;
    select count(*) into v_count
      from ddfcmes c
     where c.dfm_ano = p_ano
       and c.dfm_mes = p_mes
       and c.sub_id = p_sub
       and c.pla_id = pla.pla_id;
    if v_count = 0 then
       insert into ddfcmes (dfm_ano, dfm_mes, pro_id,     sub_id, pla_id, pla_ordem)
                    values (p_ano,   p_mes,   pla.pro_id, p_sub,  pla.pla_id, pla.pla_ordem);
    else
       update ddfcmes set dfm_saldo_real = 0, pla_ordem = pla.pla_ordem
        where dfm_ano = p_ano
          and dfm_mes = p_mes
          and sub_id = p_sub
          and pla_id = pla.pla_id;
    end if;
  end loop;
  --
  -- Atualiza recursividade
  --
  for reg in (select d.pla_id, d.dfc_vlmovim, d1.pla_idpai
                from fdfc_lacto d, dplanoconta d1
               where d.sub_id = p_sub
                 and d.dfc_rano = p_ano
                 and d.dfc_rmes = p_mes
                 and d1.pla_id = d.pla_id)
  loop
    perform prc_atua_dfc_cta (reg.pla_idpai, p_ano, p_mes, p_sub, reg.dfc_vlmovim);
  end loop;
  --
  -- Carrega vetores pela ordem da conta
  --
  for vet in (select e.dfm_id, e.dfm_saldo_real, e.pla_ordem
               from ddfcmes e
              where e.dfm_ano = p_ano
                and e.dfm_mes = p_mes
                and e.sub_id  = p_sub)
  loop
    v_vlrr[vet.pla_ordem] := vet.dfm_saldo_real;
    v_dfmid[vet.pla_ordem] := vet.dfm_id;
  end loop;
  --
  -- Formulas
  --
  v_vlrr[1000] :=  v_vlrr[2000] + v_vlrr[3000]; -- ( = ) RECEITA OPERACIONAL BRUTA
 	v_vlrr[4000] :=  v_vlrr[5000] + v_vlrr[6000] + v_vlrr[7000] + v_vlrr[8000]; -- ( - ) DEDUCOES DA RECEITA BRUTA
  v_vlrr[9000] :=  v_vlrr[1000] - v_vlrr[4000]; -- ( = ) RECEITA OPERACIONAL LÍQUIDA
 	v_vlrr[10000] :=  v_vlrr[5000] + v_vlrr[11000] + v_vlrr[12000] + v_vlrr[13000]; -- ( - ) CUSTO DO PRODUTO VENDIDO
  v_vlrr[14000] :=  v_vlrr[9000] - v_vlrr[10000]; -- ( = ) MARGEM DE CONTRIBUIÇÃO
  v_vlrr[26000] :=  v_vlrr[14000] - (v_vlrr[15000] + v_vlrr[18000]); -- ( = )EBITDA
  v_vlrr[27000] :=  v_vlrr[28000] - v_vlrr[29000]; -- (+/-) RESULTADO NÃO OPERACIONAL
  if v_vlrr[27000] < 0 then -- ( = ) SOBRA LIQUIDA
     v_vlrr[30000] := v_vlrr[26000] + v_vlrr[27000];
  else
     v_vlrr[30000] := v_vlrr[26000] - v_vlrr[27000];
  end if;
  v_vlrr[34000] :=  v_vlrr[30000] - v_vlrr[31000]; -- ( = ) FLUXO CAIXA 
  v_vlrr[37000] :=  v_vlrr[34000] - v_vlrr[35000]; -- ( = )FLUXO CAIXA LIQUIDO
  if v_vlrr[14000]/v_vlrr[1000] > 0 then -- PONTO DE EQUILÍBRIO ECONÔMICO
     v_vlrr[38000] := (v_vlrr[18000]+v_vlrr[15000])/(v_vlrr[14000]/v_vlrr[1000]);
  else
     v_vlrr[38000] := 0;
  end if;
  if v_vlrr[14000]/v_vlrr[1000] > 0 then -- PONTO DE EQUILÍBRIO ECONÔMICO
     v_vlrr[39000] := (v_vlrr[18000]+v_vlrr[15000]+v_vlrr[31000])/(v_vlrr[14000]/v_vlrr[1000]);
  else
     v_vlrr[39000] := 0;
  end if;
  
  update ddfcmes set dfm_saldo_real = v_vlrr[1000], dfm_perc_r = 100 where dfm_id = v_dfmid[1000];
  update ddfcmes set dfm_saldo_real = v_vlrr[4000], dfm_perc_r = (v_vlrr[4000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[4000];
  update ddfcmes set dfm_saldo_real = v_vlrr[9000], dfm_perc_r = (v_vlrr[9000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[9000];
  update ddfcmes set dfm_saldo_real = v_vlrr[10000], dfm_perc_r = (v_vlrr[10000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[10000];
  update ddfcmes set dfm_saldo_real = v_vlrr[14000], dfm_perc_r = (v_vlrr[14000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[14000];
  update ddfcmes set dfm_saldo_real = v_vlrr[26000], dfm_perc_r = (v_vlrr[26000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[26000];
  update ddfcmes set dfm_saldo_real = v_vlrr[27000], dfm_perc_r = (v_vlrr[27000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[27000];
  update ddfcmes set dfm_saldo_real = v_vlrr[30000], dfm_perc_r = (v_vlrr[30000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[30000];
  update ddfcmes set dfm_saldo_real = v_vlrr[34000], dfm_perc_r = (v_vlrr[34000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[34000];
  update ddfcmes set dfm_saldo_real = v_vlrr[37000], dfm_perc_r = (v_vlrr[37000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[37000];
  update ddfcmes set dfm_saldo_real = v_vlrr[38000], dfm_perc_r = (v_vlrr[38000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[38000];
  update ddfcmes set dfm_saldo_real = v_vlrr[39000], dfm_perc_r = (v_vlrr[39000] / v_vlrr[1000])*100 where dfm_id = v_dfmid[39000];
      
  return;
end;
$$;

alter function prc_atua_dfc(integer, integer, integer) owner to "SafeGold";

