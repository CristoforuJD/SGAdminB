create function prc_bor_qt_bruto(p_borid integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 06/2018
-- Atualiza bordero valor bruto e quantidade de titulos
--

reg      record;
v_total  numeric;
v_count  integer;

begin
  v_total := 0;
  for reg in (select count(bti_id) qt_tit, coalesce(sum(coalesce(bti_valor_tit,0)),0) vl_tot
                from fbortitulo a
               where a.bor_id = p_borid)
  loop
    update fbordero set bor_vlr_bruto = reg.vl_tot, bor_qtd_tit = reg.qt_tit
     where bor_id = p_borid;
  end loop;

  return;
end;
$$;

alter function prc_bor_qt_bruto(integer) owner to "SafeGold";

