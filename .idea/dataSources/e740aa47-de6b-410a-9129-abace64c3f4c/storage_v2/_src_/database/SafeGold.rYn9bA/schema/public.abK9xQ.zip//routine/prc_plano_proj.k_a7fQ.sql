create function prc_plano_proj(p_padrao_id integer, p_projeto integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 09/2018
-- Cria o plano do projeto com base no plano de contas padrao. Se o plano do projeto nao existir
--
reg     record;
x       record;
pai     record;
pai2    record;
v_count integer;
v_id    integer;
v_dt    timestamp;
v_ano   integer;
v_mes   integer;
begin
  v_count := 0;
  select count(*) into v_count
    from dplanoconta
   where pro_id = p_projeto;
  if v_count = 0 then 
     v_dt := timeofday();

     for x in (select *
                 from dplanopad
                where plp_id = p_padrao_id
                  and plp_ativo = 'S')
     loop
      for reg in (select * from dplanopadcta where plp_id = x.plp_id order by clp_ordem)
      loop
        SELECT nextval('seq_dplanoconta') into v_id;
        insert into dplanoconta (pla_id,            clp_id,        pro_id,    pla_nome,     pla_nivel,     pla_ordem,     pla_ordem_ini,
                                 pla_ordem_fim,     pla_totsn,     pla_dtsis, plp_id,       pla_dfc,       pla_dfcl,      pla_ordem_dfc)
                         values (v_id,              reg.clp_id,    p_projeto, reg.clp_nome, reg.clp_nivel, reg.clp_ordem, reg.clp_ordem_ini,
                                 reg.clp_ordem_fim, reg.clp_totsn, v_dt,      x.plp_id,     reg.clp_dfc,   reg.clp_dfcl,  reg.clp_ordem_dfc);
      end loop;
--
-- Abaixo Carrega id pai das contas DFCL
--      
      for pai in (select a.pla_id, c.pla_id id_pai
                    from dplanoconta a, dplanopadcta b, dplanoconta c
                   where a.pro_id = p_projeto
                     and b.clp_id = a.clp_id
                     and b.clp_idpai is not NULL
                     and c.pro_id = p_projeto
                     and c.clp_id = b.clp_idpai)
      loop
        update dplanoconta set pla_idpai = pai.id_pai
         where pla_id = pai.pla_id;
      end loop;
--
-- Abaixo Carrega id pai das contas DFC
--      
      for pai2 in (select a.pla_id, c.pla_id id_pai
                     from dplanoconta a, dplanopadcta b, dplanoconta c
                    where a.pro_id = p_projeto
                      and b.clp_id = a.clp_id
                      and b.clp_idpai_dfc is not NULL
                      and c.pro_id = p_projeto
                      and c.clp_id = b.clp_idpai)
      loop
        update dplanoconta set pla_idpai_dfc = pai2.id_pai
         where pla_id = pai2.pla_id;
      end loop;
     end loop;
  end if;
--
-- Abaixo Gera ordem disponivel para inclusao de futuras contas no plano de contas
--
  perform prc_plano_disp(p_projeto);
  return;
end;
$$;

alter function prc_plano_proj(integer, integer) owner to "SafeGold";

