create function prc_limites(p_bcoid integer, p_carid integer, p_proid integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 06/2018
-- Atualiza limite utilizado por carteira/banco no projeto
--

reg      record;
v_total  numeric;
v_count  integer;

begin
  v_total := 0;
  for reg in (select coalesce(sum(b.bti_valor_tit),0) vlr_tit
                from fbordero a, fbortitulo b
               where a.bco_id = p_bcoid
                 and a.car_id = p_carid
                 and a.pro_id = p_proid
                 and b.bor_id = a.bor_id
                 and b.bti_data_pagto is null)
  loop
    v_count := 0;
    select count(*) into v_count
      from dlimite a
     where a.bco_id = p_bcoid
       and a.car_id = p_carid
       and a.pro_id = p_proid;
    if v_count = 0 then
       insert into dlimite (bco_id, car_id, pro_id) values (p_bcoid, p_carid, p_proid);
    end if;
    update dlimite set lim_utilizado = reg.vlr_tit
     where bco_id = p_bcoid
       and car_id = p_carid
       and pro_id = p_proid;
  end loop;

  return;
end;
$$;

alter function prc_limites(integer, integer, integer) owner to "SafeGold";

