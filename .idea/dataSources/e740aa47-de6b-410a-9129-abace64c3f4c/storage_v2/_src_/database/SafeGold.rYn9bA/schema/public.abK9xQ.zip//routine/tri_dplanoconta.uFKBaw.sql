create function tri_dplanoconta() returns trigger
    language plpgsql
as
$$
DECLARE

v_count integer;

begin
  if TG_OP in ('INSERT','UPDATE') then
     if TG_OP = 'INSERT' then
        delete from dplanodepara
         where pro_id = new.pro_id
           and dep_ctacli = upper(trim(new.pla_nome));
        insert into dplanodepara (pla_id, dep_ctacli, pro_id) values (new.pla_id, upper(trim(new.pla_nome)), new.pro_id);
     end if;
     if TG_OP = 'UPDATE' then
        delete from dplanodepara
         where pro_id = new.pro_id
           and dep_ctacli = upper(trim(old.pla_nome));
        delete from dplanodepara
         where pro_id = new.pro_id
           and dep_ctacli = upper(trim(new.pla_nome));
        insert into dplanodepara (pla_id, dep_ctacli, pro_id) values (new.pla_id, upper(trim(new.pla_nome)), new.pro_id);
     end if;
  end if;
  --if TG_OP in ('UPDATE','DELETE') then
  if TG_OP in ('DELETE') then
     delete from dplanodepara where pla_id = old.pla_id;
     update dplanodisp set pla_id = null
      where pro_id = old.pro_id
        and pla_ordem = old.pla_ordem;
  end if;

  Return New;
end;
$$;

alter function tri_dplanoconta() owner to "SafeGold";

