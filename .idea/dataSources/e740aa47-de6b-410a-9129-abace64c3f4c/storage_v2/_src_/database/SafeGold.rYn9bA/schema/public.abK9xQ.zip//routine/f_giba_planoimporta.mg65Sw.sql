create function f_giba_planoimporta() returns void
    language plpgsql
as
$$
declare
--
-- Giba 09/2018 -- Importa plano padrao
--

reg        record;
v_vlr      numeric;
v_count    integer;

begin
  for reg in (select * from giba_plano)
  loop
    insert into dcontapad (plp_id, clp_nome, clp_ordem, clp_nivel, clp_totsn)
                   values (1,      reg.nome, reg.ordem, 1,         'S');
  end loop;
  return;
end;
$$;

alter function f_giba_planoimporta() owner to "SafeGold";

