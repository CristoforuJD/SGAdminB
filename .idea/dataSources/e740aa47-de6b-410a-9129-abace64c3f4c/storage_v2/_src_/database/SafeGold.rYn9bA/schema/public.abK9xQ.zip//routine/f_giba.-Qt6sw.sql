create function f_giba() returns void
    language plpgsql
as
$$
declare
--
-- Giba 09/2018 -- arruma ordem inicial e final
--

reg        record;
v_vlr      numeric;
v_count    integer;

begin
 update fbordero set bor_dtupdate = now(), bor_qt_recusada = 99
  where bor_id = 3;
/*  for v_i in 1 .. 50
  loop
    RAISE NOTICE '%', v_i;
  end loop;*/
  return;
end;
$$;

alter function f_giba() owner to "SafeGold";

