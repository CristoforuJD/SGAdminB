create function prc_atua_bordero(p_borid integer) returns void
    language plpgsql
as
$$
declare
--
-- Giba 06/2018 -- Primeira procedure da SafeGold ;-)
-- Atualiza bordero (liquido e etc)
--

reg        record;
v_ttarifa  numeric;
v_count    integer;

begin
  v_ttarifa := 0;
  for reg in (select coalesce(a.bor_vlr_bruto,0) bor_vlr_bruto
                from fbordero a
               where a.bor_id = p_borid)
  loop
    select sum(coalesce(b.tab_valor,0)) into v_ttarifa
      from fbortarifa b
     where b.bor_id = p_borid;
  end loop;
  update fbordero set bor_vlr_liquido = reg.bor_vlr_bruto - v_ttarifa
   where bor_id = p_borid;
  return;
end;
$$;

alter function prc_atua_bordero(integer) owner to "SafeGold";

