create function x_prc_atua_drei_mes(p_ano integer, p_mes integer, p_sub integer) returns integer
    strict
    language plpgsql
as
$$
declare
--
-- Giba 10/2016
-- Atualiza o DRE de um mes e um sub-projeto.
-- No final chama as procedures de atualizacao do consolidado DocOk
--
x          record;
y          record;
z          record;
t          record;
pv         record;
agr        record;
vis        record;
brk        record;
reg        record;
per        record;
ctas       record;
dre        record;
drs        record;
v_drsid    integer;
v_vorc     numeric;
v_vrea     numeric;
v_count    integer;
v_receitao numeric;
v_receitar numeric;
v_bk1_orc  numeric;
v_bk2_orc  numeric;
v_bk1_real numeric;
v_bk2_real numeric;
v_bk_base  numeric;
v_proj     integer;
v_dt       timestamp;
v_vlro     numeric[];
v_vlrr     numeric[];
v_pero     numeric[];
v_perr     numeric[];
v_dreid    integer[];
v_vlro_p1  numeric[];
v_vlrr_p1  numeric[];
v_vlro_p2  numeric[];
v_vlrr_p2  numeric[];

c_proj cursor is
       select pro_id
         from subprojeto
        where sub_id = p_sub;
   
c_lvd cursor(vc_plaid integer) is
      select sum(coalesce(a.lvd_orcado,0)), sum(coalesce(a.lvd_fechamento,0))
        from livromanual a
       where a.sub_id = p_sub
         and date_part('year',a.lvd_data) = p_ano
         and date_part('month',a.lvd_data) = p_mes
         and a.pla_id = vc_plaid;

begin
  open c_proj;
  fetch c_proj into v_proj;
  close c_proj;

  v_receitao := 0;
  v_receitar := 0;

  perform prc_gera_dresubmes (p_sub,p_ano,p_mes);
  update dresubmes set drs_dtatua = now()
   where sub_id = p_sub
     and drs_ano = p_ano
     and drs_mes = p_mes;
  v_drsid := null;
  for drs in (select drs_id
                from dresubmes
               where sub_id = p_sub
                 and drs_ano = p_ano
                 and drs_mes = p_mes)
  loop
    v_drsid := drs.drs_id;
  end loop;

  v_count := 0;
  for ctas in (select a.pla_id
                 from planoconta a, planoconta b
                where a.pro_id = v_proj
                  and b.pla_id = a.pla_idpai
                  and b.pla_ordem = 200
               union
               select a.pla_id
                 from planoconta a, planoconta b
                where a.pro_id = v_proj
                  and a.pla_ordem = 100)
  loop
    for dre in (select r.dre_orc, r.dre_real
                  from drefechaorca r
                 where r.dre_ano = p_ano
                    and r.dre_mes = p_mes
                   and r.sub_id  = p_sub
                   and r.pla_id  = ctas.pla_id)
    loop
-- Se ouver lancamento manual de Livro de Faturamento, estes que serao considerados para calculo da
-- receita bruta     e nao os lancamentos que ja estavam na drefechaorca, que veio de importacao excel
-- ou foram digitados
      v_vorc := 0;
      v_vrea := 0;
/*      open c_lvd (ctas.pla_id);
      fetch c_lvd into v_vorc, v_vrea;
      close c_lvd;*/
      if v_vorc <> 0 then
          v_receitao := v_receitao + v_vorc;
      else
          v_receitao := v_receitao + dre.dre_orc;
      end if;
      if v_vrea <> 0 then
         v_receitar := v_receitar + v_vrea;
      else
         v_receitar := v_receitar + dre.dre_real;
      end if;
    end loop;
  end loop;

  v_dt := timeofday();
  for z in (select g.*
              from planoconta g, subprojeto h
             where h.sub_id = p_sub
               and g.pro_id = h.pro_id order by g.pla_ordem)
  loop
     v_count := 0;
     select count(*) into v_count
       from drefechaorca d
      where d.pla_id  = z.pla_id
        and d.dre_ano = p_ano
        and d.dre_mes = p_mes
        and d.sub_id  = p_sub;
     if v_count = 0 then
        insert into drefechaorca (dre_ano, dre_mes, sub_id,   dre_datasis, dre_ordem, dre_subordem,     pla_id, drs_id, pro_id)
                          values (p_ano,   p_mes,   p_sub, v_dt,        z.pla_ordem,  z.pla_subordem, z.pla_id, v_drsid, v_proj);
     else
         if z.pla_totsn = 'S' then
             update drefechaorca set dre_orc = 0,      dre_orc_p1 = 0,      dre_orc_p2 = 0,
                                     dre_orc_per = 0,  dre_orc_p1_per = 0,  dre_orc_p2_per = 0,
                                     dre_real = 0,     dre_real_p1 = 0,     dre_real_p2 = 0,
                                     dre_real_per = 0, dre_real_p1_per = 0, dre_real_p2_per = 0,
                                     dre_ordem = z.pla_ordem,
                                     dre_subordem = z.pla_subordem, drs_id = v_drsid, pro_id = v_proj
              where pla_id  = z.pla_id
                and dre_ano = p_ano
                and dre_mes = p_mes
                and sub_id  = p_sub;
         end if;
     end if;
  end loop;
  for x in (select a.dre_id, b.pla_idpai, a.pla_id, b.pro_id, b.pla_subordem,
                   b.pla_valorperco, a.dre_orc,  a.dre_orc_per, b.pla_ordem,
                   b.pla_valorperc,  a.dre_real, a.dre_real_per, b.pla_valorperc, b.pla_valorperco
              from drefechaorca a, planoconta b
             where a.dre_ano = p_ano
               and a.dre_mes = p_mes
               and a.sub_id  = p_sub
               and b.pla_id  = a.pla_id
               and b.pla_totsn = 'N')
  loop
/*    IF x.pla_id = 7794 theN
       v_vorc := 0;
    end if;*/
    v_vorc := 0;
    v_vrea := 0;
/*    open c_lvd (x.pla_id);
    fetch c_lvd into v_vorc, v_vrea;
    close c_lvd;*/
    v_vlrr[1] := x.dre_real;
    v_vlro[1] := x.dre_orc;
    v_perr[1] := x.dre_real_per;
    v_pero[1] := x.dre_orc_per;
    if coalesce(v_vorc,0) <> 0 THEN
       v_vlro[1] := v_vorc;
    end if;

    if coalesce(v_vrea,0) <> 0 THEN
       v_vlrr[1] := v_vrea;
    end if;

    if v_receitar <> 0 then
          if x.pla_ordem > 399 then
             if x.pla_valorperc = 'V' then
                v_perr[1] := round((v_vlrr[1]/v_receitar)*100,10);
             else
                if v_perr[1] <> 0 then                
                   v_vlrr[1] := round((v_perr[1]*v_receitar)/100,10);
                end if;
             end if;
          else
             v_perr[1] := round((v_vlrr[1]/v_receitar)*100,10);
          end if;
    end if;

    if v_receitao <> 0 then
       if x.pla_ordem > 399 then
          if x.pla_valorperco = 'V' then
             v_pero[1] := round((v_vlro[1]/v_receitao)*100,10);
          else
             if v_pero[1] <> 0 then
                v_vlro[1] := round((v_pero[1]*v_receitao)/100,10);
             end if;
          end if;
       else
           v_pero[1] := round((v_vlro[1]/v_receitao)*100,10);
       end if;
    end if;

    update drefechaorca set dre_orc_per = v_pero[1], dre_orc = v_vlro[1],
                            dre_real_per = v_perr[1], dre_real = v_vlrr[1],
                            dre_ordem = x.pla_ordem, dre_subordem = x.pla_subordem, pro_id = v_proj, drs_id = v_drsid
     where dre_id = x.dre_id;
    perform prc_atua_cta(x.pla_idpai, p_ano, p_mes, p_sub, v_vlro[1], x.dre_orc_per, v_vlrr[1], x.dre_real_per);

  end loop;

  for reg in (select a.dre_id, a.dre_orc, a.dre_real, b.pla_ordem
               from drefechaorca a, planoconta b
              where a.dre_ano = p_ano
                and a.dre_mes = p_mes
                and a.sub_id  = p_sub
                and a.dre_subordem = 1
                and b.pla_id  = a.pla_id order by b.pla_ordem)
  loop
    v_vlro[reg.pla_ordem] := reg.dre_orc;
    v_vlrr[reg.pla_ordem] := reg.dre_real;
    v_dreid[reg.pla_ordem] := reg.dre_id;
  end loop;
--  v_vlro[1200] := v_vlro[200] - v_vlro[400]; -- Receita Liquida Orcamento orcado
--  v_vlrr[1200] := v_vlrr[200] - v_vlrr[400]; -- Receita Liquida Realizado realizado
  v_vlro[1200] := v_vlro[0] - v_vlro[400]; -- Receita Liquida Orcamento orcado
  v_vlrr[1200] := v_vlrr[0] - v_vlrr[400]; -- Receita Liquida Realizado realizado
  v_vlro[2300] := v_vlro[1200] - v_vlro[1300]; -- Margem de contribuicao orcado
  v_vlrr[2300] := v_vlrr[1200] - v_vlrr[1300]; -- Margem de contribuicao realizado
  v_vlro[12100] := v_vlro[2300] - v_vlro[2400]; -- EBITIDA I orcado
  v_vlrr[12100] := v_vlrr[2300] - v_vlrr[2400]; -- EBITIDA I realizado
  v_vlro[12200] := v_vlro[12300] - v_vlro[13400]; -- Saldo Nao Operacional orcado
  v_vlrr[12200] := v_vlrr[12300] - v_vlrr[13400]; -- Saldo Nao Operacional realizado
  v_vlro[15200] := v_vlro[12100] - (-v_vlro[12200]); -- EBITIDA II orcado
  v_vlrr[15200] := v_vlrr[12100] - (-v_vlrr[12200]); -- EBITIDA II realizado
  v_vlro[15500] := v_vlro[15200] - (v_vlro[15300]+v_vlro[15400]); -- Resultado Operacional orcado
  v_vlrr[15500] := v_vlrr[15200] - (v_vlrr[15300]+v_vlrr[15400]);  -- Resultado Operacional realizado
  v_vlro[16000] := (v_vlro[16100]-v_vlro[17000]); -- SALDO DE ORIGEM X APLICACAO
  v_vlrr[16000] := (v_vlrr[16100]-v_vlrr[17000]); -- SALDO DE ORIGEM X APLICACAO
  v_vlro[18000] := v_vlro[15500] + (v_vlro[16000]); -- EBITIDA III orcado
  v_vlrr[18000] := v_vlrr[15500] + (v_vlrr[16000]); -- EBITIDA III realizado
      
  update drefechaorca set dre_orc = v_vlro[1200], dre_real = v_vlrr[1200]
   where dre_id = v_dreid[1200];
  update drefechaorca set dre_orc = v_vlro[2300], dre_real = v_vlrr[2300]
   where dre_id = v_dreid[2300];
  update drefechaorca set dre_orc = v_vlro[12100], dre_real = v_vlrr[12100]
   where dre_id = v_dreid[12100];
  update drefechaorca set dre_orc = v_vlro[12200], dre_real = v_vlrr[12200]
   where dre_id = v_dreid[12200];
  update drefechaorca set dre_orc = v_vlro[15200], dre_real = v_vlrr[15200]
   where dre_id = v_dreid[15200];
  update drefechaorca set dre_orc = v_vlro[15500], dre_real = v_vlrr[15500]
   where dre_id = v_dreid[15500];
  update drefechaorca set dre_orc = v_vlro[16000], dre_real = v_vlrr[16000]
   where dre_id = v_dreid[16000];
  update drefechaorca set dre_orc = v_vlro[18000], dre_real = v_vlrr[18000]
   where dre_id = v_dreid[18000];

--
-- Define os percentuais
--  
  update drefechaorca set dre_orc_per = 
                          CASE WHEN coalesce(v_vlro[0],0) = 0
                           THEN 0
                           ELSE round(round(dre_orc/v_vlro[0],10)*100,10)
                          end,
                          dre_real_per =
                          CASE WHEN coalesce(v_vlrr[0],0) = 0
                           THEN 0
                           ELSE round(round(dre_real/v_vlrr[0],10)*100,10)
                          end
   where dre_ano = p_ano
     and dre_mes = p_mes
     and sub_id  = p_sub;
--===========================================================================================================================================
--===========================================================================================================================================
-- Break even I e II
-- Break even I = valor de custos fixos (2400) dividido por o Perc. da margem de contribuicao (2300)
-- Break even II = Custos fixos (2400) - saldo nao operacional (12200) divididos pelo Perc. da margem de contribuicao (2300)
  v_bk1_orc := 0;
  v_bk2_orc := 0;
  if v_vlro[0] <> 0 and v_vlro[2300] <> 0 then
     v_bk1_orc := round(v_vlro[2400],15)/round(v_vlro[2300]/v_vlro[0],15);
     v_bk_base := v_vlro[2400]-v_vlro[12200];
     v_bk2_orc := round(v_bk_base,15)/round(v_vlro[2300]/v_vlro[0],15);
  end if;
  v_bk1_real := 0;
  v_bk2_real := 0;
  if v_vlrr[0] <> 0 and v_vlrr[2300] <> 0 then
     v_bk1_real := round(v_vlrr[2400],15)/round(v_vlrr[2300]/v_vlrr[0],15);
     v_bk_base := v_vlrr[2400]-v_vlrr[12200];
     v_bk2_real := round(v_bk_base,15)/round(v_vlrr[2300]/v_vlrr[0],15);
  end if;
  for brk in (select b.pla_totsn, b.pla_valorperc, a.dre_id, b.pla_ordem, 
                     a.dre_orc, a.dre_orc_per, a.dre_real, a.dre_real_per, b.pla_idpai, b.pla_id
                from drefechaorca a, planoconta b
               where a.dre_ano = p_ano
                 and a.dre_mes = p_mes
                 and a.sub_id  = p_sub
                 and b.pla_id  = a.pla_id order by b.pla_ordem)
  loop
     if brk.pla_totsn = 'N' then
        if brk.pla_valorperc = 'P' then
           update drefechaorca set dre_orc_p1 = round(v_bk1_orc*(brk.dre_orc_per/100),4),
                                   dre_orc_p2 = round(v_bk2_orc*(brk.dre_orc_per/100),4),
                                   dre_orc_p1_per = brk.dre_orc_per,
                                   dre_orc_p2_per = brk.dre_orc_per,
                                   dre_real_p1 = round(v_bk1_real*(brk.dre_real_per/100),4),
                                   dre_real_p2 = round(v_bk2_real*(brk.dre_real_per/100),4),
                                   dre_real_p1_per = brk.dre_real_per,
                                   dre_real_p2_per = brk.dre_real_per
            where dre_id = brk.dre_id;
        else
           update drefechaorca set dre_orc_p1 = brk.dre_orc,
                                   dre_orc_p2 = brk.dre_orc,
                                   dre_orc_p1_per = CASE WHEN v_bk1_orc = 0
                                                    then 0
                                                    else round((brk.dre_orc/v_bk1_orc)*100,2) end,
                                   dre_orc_p2_per = case when v_bk2_orc = 0 
                                                    then 0
                                                    else round((brk.dre_orc/v_bk2_orc)*100,2) end,
                                   dre_real_p1 = brk.dre_real,
                                   dre_real_p2 = brk.dre_real,
                                   dre_real_p1_per = CASE WHEN v_bk1_real = 0
                                                     then 0
                                                     else round((brk.dre_real/v_bk1_real)*100,2) end,
                                   dre_real_p2_per = case when v_bk2_real = 0 
                                                     then 0
                                                     else round((brk.dre_real/v_bk2_real)*100,2) end
            where dre_id = brk.dre_id;
        end if;
     end if;
  end loop;

  for y in (select a.dre_id, a.dre_orc_p1, a.dre_orc_p2, a.dre_real_p1, a.dre_real_p2, b.pla_idpai
              from drefechaorca a, planoconta b
             where a.dre_ano = p_ano
               and a.dre_mes = p_mes
               and a.sub_id  = p_sub
               and b.pla_id  = a.pla_id
               and b.pla_totsn = 'N')
  loop
     if y.dre_orc_p1 <> 0 or y.dre_orc_p2 <> 0 then
        perform prc_atua_bre(y.pla_idpai, p_ano, p_mes, p_sub, 'O', y.dre_orc_p1, y.dre_orc_p2);
     end if;
     if y.dre_real_p1 <> 0 or y.dre_real_p2 <> 0 then
        perform prc_atua_bre(y.pla_idpai, p_ano, p_mes, p_sub, 'R', y.dre_real_p1, y.dre_real_p2);
     end if;
  end loop;

  for reg in (select a.dre_id, a.dre_orc_p1, a.dre_real_p1, a.dre_orc_p2, a.dre_real_p2, b.pla_ordem
               from drefechaorca a, planoconta b
              where a.dre_ano = p_ano
                and a.dre_mes = p_mes
                and a.sub_id  = p_sub
                and a.dre_subordem = 1
                and b.pla_id  = a.pla_id)
  loop
    v_vlro_p1[reg.pla_ordem] := reg.dre_orc_p1;
    v_vlrr_p1[reg.pla_ordem] := reg.dre_real_p1;
    v_vlro_p2[reg.pla_ordem] := reg.dre_orc_p2;
    v_vlrr_p2[reg.pla_ordem] := reg.dre_real_p2;
    v_dreid[reg.pla_ordem] := reg.dre_id;
  end loop;
--  v_vlro_p1[1200] := v_vlro_p1[200] - v_vlro_p1[400]; -- Receita Liquida Orcamento orcado
--  v_vlrr_p1[1200] := v_vlrr_p1[200] - v_vlrr_p1[400]; -- Receita Liquida Realizado realizado
  v_vlro_p1[1200] := v_vlro_p1[0] - v_vlro_p1[400]; -- Receita Liquida Orcamento orcado
  v_vlrr_p1[1200] := v_vlrr_p1[0] - v_vlrr_p1[400]; -- Receita Liquida Realizado realizado
  v_vlro_p1[2300] := v_vlro_p1[1200] - v_vlro_p1[1300]; -- Margem de contribuicao orcado
  v_vlrr_p1[2300] := v_vlrr_p1[1200] - v_vlrr_p1[1300]; -- Margem de contribuicao realizado
  v_vlro_p1[12100] := v_vlro_p1[2300] - v_vlro_p1[2400]; -- EBITIDA I orcado
  v_vlrr_p1[12100] := v_vlrr_p1[2300] - v_vlrr_p1[2400]; -- EBITIDA I realizado
  v_vlro_p1[12200] := v_vlro_p1[12300] - v_vlro_p1[13400]; -- Saldo Nao Operacional orcado
  v_vlrr_p1[12200] := v_vlrr_p1[12300] - v_vlrr_p1[13400]; -- Saldo Nao Operacional realizado
  v_vlro_p1[15200] := v_vlro_p1[12100] - (-v_vlro_p1[12200]); -- EBITIDA II orcado
  v_vlrr_p1[15200] := v_vlrr_p1[12100] - (-v_vlrr_p1[12200]); -- EBITIDA II realizado
  v_vlro_p1[15500] := v_vlro_p1[15200] - (v_vlro_p1[15300]+v_vlro_p1[15400]); -- Resultado Operacional orcado
  v_vlrr_p1[15500] := v_vlrr_p1[15200] - (v_vlrr_p1[15300]+v_vlrr_p1[15400]);  -- Resultado Operacional realizado
  v_vlro_p1[16000] := (v_vlro_p1[16100]-v_vlro_p1[17000]); -- SALDO DE ORIGEM X APLICACAO
  v_vlrr_p1[16000] := (v_vlrr_p1[16100]-v_vlrr_p1[17000]); -- SALDO DE ORIGEM X APLICACAO
  v_vlro_p1[18000] := v_vlro_p1[15500] + (v_vlro_p1[16000]); -- EBITIDA II orcado
  v_vlrr_p1[18000] := v_vlrr_p1[15500] + (v_vlrr_p1[16000]); -- EBITIDA II realizado
  
--  v_vlro_p2[1200] := v_vlro_p2[200] - v_vlro_p2[400]; -- Receita Liquida Orcamento orcado
--  v_vlrr_p2[1200] := v_vlrr_p2[200] - v_vlrr_p2[400]; -- Receita Liquida Realizado realizado
  v_vlro_p2[1200] := v_vlro_p2[0] - v_vlro_p2[400]; -- Receita Liquida Orcamento orcado
  v_vlrr_p2[1200] := v_vlrr_p2[0] - v_vlrr_p2[400]; -- Receita Liquida Realizado realizado
  v_vlro_p2[2300] := v_vlro_p2[1200] - v_vlro_p2[1300]; -- Margem de contribuicao orcado
  v_vlrr_p2[2300] := v_vlrr_p2[1200] - v_vlrr_p2[1300]; -- Margem de contribuicao realizado
  v_vlro_p2[12100] := v_vlro_p2[2300] - v_vlro_p2[2400]; -- EBITIDA I orcado
  v_vlrr_p2[12100] := v_vlrr_p2[2300] - v_vlrr_p2[2400]; -- EBITIDA I realizado
  v_vlro_p2[12200] := v_vlro_p2[12300] - v_vlro_p2[13400]; -- Saldo Nao Operacional orcado
  v_vlrr_p2[12200] := v_vlrr_p2[12300] - v_vlrr_p2[13400]; -- Saldo Nao Operacional realizado
  v_vlro_p2[15200] := v_vlro_p2[12100] - (-v_vlro_p2[12200]); -- EBITIDA II orcado
  v_vlrr_p2[15200] := v_vlrr_p2[12100] - (-v_vlrr_p2[12200]); -- EBITIDA II realizado
  v_vlro_p2[15500] := v_vlro_p2[15200] - (v_vlro_p2[15300]+v_vlro_p2[15400]); -- Resultado Operacional orcado
  v_vlrr_p2[15500] := v_vlrr_p2[15200] - (v_vlrr_p2[15300]+v_vlrr_p2[15400]);  -- Resultado Operacional realizado
  v_vlro_p2[16000] := (v_vlro_p2[16100]-v_vlro_p2[17000]); -- SALDO DE ORIGEM X APLICACAO
  v_vlrr_p2[16000] := (v_vlrr_p2[16100]-v_vlrr_p2[17000]); -- SALDO DE ORIGEM X APLICACAO
  v_vlro_p2[18000] := v_vlro_p2[15500] + (v_vlro_p2[16000]); -- EBITIDA II orcado
  v_vlrr_p2[18000] := v_vlrr_p2[15500] + (v_vlrr_p2[16000]); -- EBITIDA II realizado
      
  update drefechaorca set dre_orc_p1 = v_vlro_p1[1200], dre_real_p1 = v_vlrr_p1[1200],
                          dre_orc_p2 = v_vlro_p2[1200], dre_real_p2 = v_vlrr_p2[1200]
   where dre_id = v_dreid[1200];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[2300], dre_real_p1 = v_vlrr_p1[2300],
                          dre_orc_p2 = v_vlro_p2[2300], dre_real_p2= v_vlrr_p2[2300]
   where dre_id = v_dreid[2300];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[12100], dre_real_p1 = v_vlrr_p1[12100],
                          dre_orc_p2 = v_vlro_p2[12100], dre_real_p2 = v_vlrr_p2[12100]
   where dre_id = v_dreid[12100];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[12200], dre_real_p1 = v_vlrr_p1[12200],
                          dre_orc_p2 = v_vlro_p2[12200], dre_real_p2 = v_vlrr_p2[12200]
   where dre_id = v_dreid[12200];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[15200], dre_real_p1 = v_vlrr_p1[15200],
                          dre_orc_p2 = v_vlro_p2[15200], dre_real_p2 = v_vlrr_p2[15200]
   where dre_id = v_dreid[15200];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[15500], dre_real_p1 = v_vlrr_p1[15500],
                          dre_orc_p2 = v_vlro_p2[15500], dre_real_p2 = v_vlrr_p2[15500]
   where dre_id = v_dreid[15500];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[16000], dre_real_p1 = v_vlrr_p1[16000],
                          dre_orc_p2 = v_vlro_p2[16000], dre_real_p2 = v_vlrr_p2[16000]
   where dre_id = v_dreid[16000];
  update drefechaorca set dre_orc_p1 = v_vlro_p1[18000], dre_real_p1 = v_vlrr_p1[18000],
                          dre_orc_p2 = v_vlro_p2[18000], dre_real_p2 = v_vlrr_p2[18000]
   where dre_id = v_dreid[18000];

  for t in (select a.dre_id
              from drefechaorca a, planoconta b
             where a.dre_ano = p_ano
               and a.dre_mes = p_mes
               and a.sub_id  = p_sub
               and b.pla_id  = a.pla_id
               and b.pla_totsn = 'S')
  loop
           update drefechaorca set dre_orc_p1_per = CASE WHEN v_bk1_orc = 0
                                                    then 0
                                                    else round((dre_orc_p1/v_bk1_orc)*100,2) end,
                                   dre_orc_p2_per = case when v_bk2_orc = 0 
                                                    then 0
                                                    else round((dre_orc_p2/v_bk2_orc)*100,2) end,
                                   dre_real_p1_per = CASE WHEN v_bk1_real = 0
                                                     then 0
                                                     else round((dre_real_p1/v_bk1_real)*100,2) end,
                                   dre_real_p2_per = case when v_bk2_real = 0 
                                                     then 0
                                                     else round((dre_real_p2/v_bk2_real)*100,2) end
            where dre_id = t.dre_id;
  end loop;
  perform prc_atua_dre_mes_consolidado (p_ano, p_mes, v_proj);
  for agr in (select a.agr_id
                from subagrupado a
               where a.sub_id = p_sub)
  loop
   v_count := 0;
   select count(*) into v_count
     from agrupatua a
    where a.aga_ano = p_ano
      and a.aga_mes = p_mes
      and a.agr_id  = agr.agr_id;
   if v_count = 0 then
      insert into agrupatua (aga_ano, aga_mes, agr_id) values (p_ano, p_mes, agr.agr_id);
   end if;
   update agrupatua set aga_atualizado = 'N', aga_dtsis = null
    where agr_id  = agr.agr_id
      and aga_ano = p_ano
      and aga_mes = p_mes;
  end loop;
  
  for vis in (select a.vgr_id
                from visaodresub a
               where a.sub_id = p_sub)
  loop
   v_count := 0;
   select count(*) into v_count
     from visaoatua a
    where a.vga_ano = p_ano
      and a.vga_mes = p_mes
      and a.vgr_id  = vis.vgr_id;
   if v_count = 0 then
      insert into visaoatua (vga_ano, vga_mes, vgr_id) values (p_ano, p_mes, vis.vgr_id);
   end if;
   update visaoatua set vga_atualizado = 'N', vga_dtsis = null
    where vgr_id  = vis.vgr_id
      and vga_ano = p_ano
      and vga_mes = p_mes;
  end loop;

  return 0;
end;
$$;

alter function x_prc_atua_drei_mes(integer, integer, integer) owner to "SafeGold";

